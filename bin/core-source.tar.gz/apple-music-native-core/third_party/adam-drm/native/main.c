/*
 * main.c — Apple Music FairPlay 解密 wrapper 的 Android 层主程序
 * (运行在 rootfs chroot 内, 由 wrapper.c / wrapper-rootless.c 启动)
 *
 * 架构:
 *   持有效 Apple Music 订阅的账户, 通过 Android 原生库
 *   (libandroidappmusic.so / libstoreservicescore.so / libmediaplatform.so /
 *    libCoreLSKD.so) 完成登录 + FairPlay 密钥派生, 再把解密能力暴露为 4 个本地 TCP 服务:
 *
 *     10020 decrypt-port  样本解密服务 (CBC): 收 [1B len][adam][1B len][uri]
 *                          再循环收 [4B size][密文] → NfcR 解密 → 写回等长明文
 *     20020 m3u8-port     歌曲流地址服务:    收 [1B len][adamId] → 返回 M3U8 URL
 *     30020 account-port  账号信息 JSON 服务
 *     40020 key-port      key 服务 (HTTP):  ?adamId=&uri= → 返回
 *                          {contentKey, ctx, state, rcx/rax/rdx/r9/rbp} 解密模板
 *
 *   40020 的 ctx/state/寄存器模板由 R1 入口 (libCoreLSKD+0x1d5709) 的 Dobby hook
 *   捕获, 供纯 Python 离线解密器 (decryption/src/decrypt_tool.py --content-server)
 *   对任意新音轨做完全离线解密。见 decryption/docs/offline-decryption.md。
 *
 * 构建: CMakeLists.txt (NDK clang; cmake -DMYRELEASE=ON 切换 Release) — R1 key-server
 *   hook (Dobby) 两种模式都编译; curl/log debug hook 仅 Debug
 */
#include <errno.h>
#include <stdint.h>
#include <setjmp.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <stdarg.h>
#include <ctype.h>

#ifdef _WIN32
#include <winsock2.h>
#include <ws2tcpip.h>
#define SOCK_CLOEXEC 0
#ifndef SO_REUSEPORT
#define SO_REUSEPORT SO_REUSEADDR
#endif
#define read(fd, buffer, length) recv((SOCKET)(fd), (char *)(buffer), (int)(length), 0)
#define write(fd, buffer, length) send((SOCKET)(fd), (const char *)(buffer), (int)(length), 0)
#define close(fd) closesocket((SOCKET)(fd))
static inline int hybris_windows_setsockopt(int fd, int level, int option,
                                            const void *value, int length)
{
    return setsockopt((SOCKET)fd, level, option, (const char *)value, length);
}
#define setsockopt hybris_windows_setsockopt
static inline int accept4(int fd, struct sockaddr *address, int *address_length,
                          int flags)
{
    (void)flags;
    return (int)accept((SOCKET)fd, address, address_length);
}
#ifndef EHOSTDOWN
#define EHOSTDOWN ENETDOWN
#endif
#ifndef ENONET
#define ENONET ENETDOWN
#endif
static inline int hybris_windows_setenv(const char *name, const char *value,
                                        int overwrite)
{
    if (!overwrite && getenv(name) != NULL) return 0;
    return _putenv_s(name, value != NULL ? value : "");
}
#define setenv hybris_windows_setenv
#else
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <link.h>
#endif
#include <sys/stat.h>

#include "import.h"
#include "cmdline.h"
#include "cJSON.h"
#include "music_token_request.h"
#include "subscription_status.h"
#include "dobby.h"

struct shared_ptr apInf;
uint8_t leaseMgr[16];
struct shared_ptr reqCtx;
struct gengetopt_args_info args_info;
char *amUsername, *amPassword;
/* Length of the bare password in amPassword. Apple asks for the 2FA code once
 * per attempt and the code is appended to the password, so it is cut back to
 * this length first; otherwise a second prompt sends password+code1+code2. */
size_t amPasswordLen;
/* The reason the last sign-in failed (Apple's own wording when it gave one), for the host to show. */
char g_last_auth_error[256];
/* Set when the host gave no verification code (the user cancelled or the wait ran out). */
static int g_auth_cancelled;
/* Title and text of the last dialog Apple raised during the sign-in ("Forgot Your Password?: ..."). */
static char g_last_dialog[384];
struct shared_ptr g_GUID;
int decryptCount = 1000;
int offlineFlag;
char *device_infos[9];

char *g_storefront_id = NULL;
char *g_dev_token = NULL;
char *g_music_token = NULL;

// itun FairPlay decryptor for progressive MV
pthread_mutex_t g_itun_mutex = PTHREAD_MUTEX_INITIALIZER;
struct shared_ptr g_itun_decryptor = {.obj = NULL, .ctrl_blk = NULL};
unsigned long g_itun_adam_id = 0;

/* Library-mode callbacks — set by drm_lib_init(), NULL in binary mode. */
#include "drm_lib.h"
#include "mygo_diagnostics.h"
drm_auth_cb_t  g_drm_auth_cb  = NULL;
void          *g_drm_auth_ud  = NULL;
drm_state_cb_t g_drm_state_cb = NULL;
void          *g_drm_state_ud = NULL;

/* Write a single-word state token to base_dir/drm-state.
 * The Go engine reads this file via inotify to track wrapper lifecycle.
 * States: STARTING  LOGIN  WAITING_2FA  INITIALIZING_FAIRPLAY  RUNNING
 *         RECOVERY  FAILED  STOPPED
 * In library mode, also fires g_drm_state_cb if set.
 */
static void write_drm_state(const char *state) {
    if (g_drm_state_cb) g_drm_state_cb(state, g_drm_state_ud);
    if (!args_info.base_dir_arg) return;
    char path[512];
    snprintf(path, sizeof(path), "%s/drm-state", args_info.base_dir_arg);
    FILE *fp = fopen(path, "w");
    if (!fp) return;
    fprintf(fp, "%s\n", state);
    fclose(fp);
}

/* Protects preshareCtx against concurrent access from the main decrypt
 * thread (handle/getKdContext) and the recovery worker (refresh_decrypt_ctx).
 * Using PTHREAD_MUTEX_INITIALIZER avoids the need for an explicit init call. */
static pthread_mutex_t g_ctx_mutex = PTHREAD_MUTEX_INITIALIZER;

#ifndef MyRelease
static int (*orig_debug_log_enabled)(void);
static int (*orig_android_log_print)(int prio, const char *tag, const char *fmt, ...);
static int (*orig_android_log_write)(int prio, const char *tag, const char *text);
static int (*orig_curl_easy_setopt)(void *curl, int option, ...);

int32_t CURLOPT_SSL_VERIFYPEER = 64;
int32_t CURLOPT_SSL_VERIFYHOST = 81;
int32_t CURLOPT_PINNEDPUBLICKEY = 10230;
int32_t CURLOPT_VERBOSE = 43;

int curl_easy_setopt_hook(void *curl, int32_t option, ...) {
    va_list args;
    va_start(args, option);
    void* param = va_arg(args, void*);
    va_end(args);
 
    if (option == CURLOPT_SSL_VERIFYPEER || 
        option == CURLOPT_SSL_VERIFYHOST || 
        option == CURLOPT_PINNEDPUBLICKEY) {
        DRM_DEBUG("[+] hooked curl_easy_setopt %d\n", option);
        orig_curl_easy_setopt(curl, CURLOPT_VERBOSE, 1L);
        return orig_curl_easy_setopt(curl, option, 0L);
    }  else {
        return orig_curl_easy_setopt(curl, option, param);
    }
 
}

int android_log_print_hook(int prio, const char *tag, const char *fmt, ...) {
    char log_buffer[1024];
    va_list args;
    va_start(args, fmt);
    vsnprintf(log_buffer, sizeof(log_buffer), fmt, args);
    va_end(args);
    fprintf(stderr, "[%s] %s\n", tag, log_buffer);
    return 0;
}

int android_log_write_hook(int prio, const char *tag, const char *text) {
    fprintf(stderr, "[%s] %s\n", tag, text);
    return 0;
}

static uint8_t allDebug() { return 1; }

void install_hooks() {
    DobbyHook((void*)_ZN13mediaplatform26DebugLogEnabledForPriorityENS_11LogPriorityE,
              (void*)allDebug,
              (void**)&orig_debug_log_enabled);

    DobbyHook((void*)__android_log_print, 
              (void*)android_log_print_hook, 
              (void**)&orig_android_log_print);

    DobbyHook((void*)__android_log_write, 
              (void*)android_log_write_hook, 
              (void**)&orig_android_log_write);

    DobbyHook((void*)curl_easy_setopt,
              (void*)curl_easy_setopt_hook,
              (void**)&orig_curl_easy_setopt);
}
#endif

int file_exists(char *filename) {
  struct stat buffer;   
  return (stat (filename, &buffer) == 0);
}

char *strcat_b(char *dest, char* src) {
    size_t len1 = strlen(dest);
    size_t len2 = strlen(src);

    char *result = malloc(len1 + len2 + 1);
    if (!result) return NULL; 

    strcpy(result, dest);
    strcat(result, src);

    return result;
}

/* The statically-linked SQLite inside libmediaplatform uses the bionic (unix)
 * VFS, whose unixFullPathname() treats any path not starting with '/' as
 * relative and prepends getcwd(). A Windows path like "C:\Users\..." is thus
 * mangled into "C:\adam-build/C:\Users\...", and the DB open fails ("Database
 * connection lost or invalid."). Hand libmediaplatform a POSIX-absolute path
 * ("/C:/Users/...") so the VFS takes its absolute branch — no getcwd, no lstat
 * symlink loop. The hook table (windows_hook_table.c) strips the leading '/'
 * back off before the real Win32 open(). Backslashes become forward slashes.
 * A path that is already POSIX-absolute is returned unchanged. */
char *drm_posix_path(const char *win) {
    if (!win) return NULL;
    size_t n = strlen(win);
    char *r = malloc(n + 2);
    if (!r) return NULL;
    size_t j = 0;
    if (win[0] != '/') r[j++] = '/';   /* prepend '/' for "C:\..." style */
    for (size_t i = 0; i < n; i++) r[j++] = (win[i] == '\\') ? '/' : win[i];
    r[j] = '\0';
    return r;
}

int split_string_safe(const char *str, const char *delim, char **components, 
                      int max_components, char **out_copy_to_free) 
{
    *out_copy_to_free = NULL;

    char *copy = strdup(str);
    if (copy == NULL) {
        return -1; 
    }

    *out_copy_to_free = copy;

    int count = 0;
    char *saveptr;
    char *token;

    token = strtok_r(copy, delim, &saveptr);

    while (token != NULL && count < max_components) {
        components[count] = token;
        count++;
        token = strtok_r(NULL, delim, &saveptr);
    }

    return count;
}

static void __attribute__((sysv_abi)) dialogHandler(int64_t j, struct shared_ptr *protoDialogPtr,
                          struct shared_ptr *respHandler) {
    const char *const title = std_string_data(
        _ZNK17storeservicescore14ProtocolDialog5titleEv(protoDialogPtr->obj));
    const char *const dialog_text = std_string_data(_ZNK17storeservicescore14ProtocolDialog7messageEv(
        protoDialogPtr->obj));
    DRM_DEBUG("[.] dialogHandler: {title: %s, message: %s}\n", title, dialog_text);
    if (title && *title && strcmp(title, "Sign In") != 0) {
        /* Keep what Apple said: the host shows it, and tells a locked account from a wrong password by it. */
        if (dialog_text && *dialog_text)
            snprintf(g_last_dialog, sizeof(g_last_dialog), "%s: %s", title, dialog_text);
        else
            snprintf(g_last_dialog, sizeof(g_last_dialog), "%s", title);
    }

    /* The library keeps this response (and its control block) after the handler returns and processes it on another
     * thread, so it must not live on this stack frame. Never freed: the library holds shared references. */
    unsigned char *const ptr = calloc(1, 72);
    *(void **)(ptr) =
        &_ZTVNSt6__ndk120__shared_ptr_emplaceIN17storeservicescore22ProtocolDialogResponseENS_9allocatorIS2_EEEE +
        2;
    struct shared_ptr diagResp = {.obj = ptr + 24, .ctrl_blk = ptr};
    _ZN17storeservicescore22ProtocolDialogResponseC1Ev(diagResp.obj);

    struct std_vector *butVec =
        _ZNK17storeservicescore14ProtocolDialog7buttonsEv(protoDialogPtr->obj);
    if (strcmp("Sign In", title) == 0) {
        for (struct shared_ptr *b = butVec->begin; b != butVec->end; ++b) {
            if (strcmp("Use Existing Apple ID",
                       std_string_data(
                           _ZNK17storeservicescore14ProtocolButton5titleEv(
                               b->obj))) == 0) {
                _ZN17storeservicescore22ProtocolDialogResponse17setSelectedButtonERKNSt6__ndk110shared_ptrINS_14ProtocolButtonEEE(
                    diagResp.obj, b);
                break;
            }
        }
    } else {
        // Auto-dismiss: select the first button ("Not Now" for concurrent-stream dialogs, etc.).
        // Without a selected button handleProtocolDialogResponse dereferences NULL → SIGSEGV.
        struct shared_ptr *first_btn = butVec->begin;
        if (first_btn != (struct shared_ptr *)butVec->end) {
            DRM_DEBUG("[.] dialogHandler: auto-dismissing '%s'\n",
                    std_string_data(
                        _ZNK17storeservicescore14ProtocolButton5titleEv(
                            first_btn->obj)));
            _ZN17storeservicescore22ProtocolDialogResponse17setSelectedButtonERKNSt6__ndk110shared_ptrINS_14ProtocolButtonEEE(
                diagResp.obj, first_btn);
        }
    }
    _ZN20androidstoreservices28AndroidPresentationInterface28handleProtocolDialogResponseERKlRKNSt6__ndk110shared_ptrIN17storeservicescore22ProtocolDialogResponseEEE(
        apInf.obj, &j, &diagResp);
}

static void __attribute__((sysv_abi)) credentialHandler(struct shared_ptr *credReqHandler,
                              struct shared_ptr *credRespHandler) {
    const uint8_t need2FA =
        _ZNK17storeservicescore18CredentialsRequest28requiresHSA2VerificationCodeEv(
            credReqHandler->obj);
    mygo_native_diagnostic("credentials_requested", 1);
    if (need2FA) mygo_native_diagnostic("two_factor_requested", 1);
    fprintf(
        stderr, "[.] credentialHandler: {title: %s, message: %s, 2FA: %s}\n",
        std_string_data(_ZNK17storeservicescore18CredentialsRequest5titleEv(
            credReqHandler->obj)),
        std_string_data(_ZNK17storeservicescore18CredentialsRequest7messageEv(
            credReqHandler->obj)),
        need2FA ? "true" : "false");

    int cancelled = 0;
    if (!amUsername || !amPassword) {
        /* Nobody is signing in (the credentials are dropped once a sign-in ends): Apple wants the
         * account again mid-session, e.g. an expired token. Answering would resubmit an old password
         * or ask for a code nobody expects; cancel and let the host show its own sign-in. */
        fprintf(stderr, "[.] credentialHandler: no sign-in in progress, cancelling the request\n");
        cancelled = 1;
        g_auth_cancelled = 1;
        mygo_native_diagnostic("credentials_cancelled", 1);
    }
    if (!cancelled && amPasswordLen && strlen(amPassword) > amPasswordLen)
        amPassword[amPasswordLen] = '\0';
    int passLen = cancelled ? 0 : (int)strlen(amPassword);

    if (need2FA && !cancelled) {
        write_drm_state("WAITING_2FA");
        if (g_drm_auth_cb) {
            /* library mode: ask the Go engine for the 2FA code */
            char code[16] = {0};
            g_drm_auth_cb("2fa", code, sizeof(code), g_drm_auth_ud);
            if (code[0] == '\0') {
                /* No code: answering with the bare password would only count as another wrong attempt
                 * at Apple, and repeated ones lock the account. Cancel instead. */
                cancelled = 1;
                g_auth_cancelled = 1;
            } else {
                strncat(amPassword, code, 6);
            }
        } else if (args_info.code_from_file_flag) {
            fprintf(stderr, "[!] Enter your 2FA code into rootfs/%s/2fa.txt\n", args_info.base_dir_arg);
            fprintf(stderr, "[!] Example command: echo -n 123456 > rootfs/%s/2fa.txt\n", args_info.base_dir_arg);
            fprintf(stderr, "[!] Waiting for input...\n");
            int count = 0;
            while (1)
            {
                if (count >= 20) {
                    fprintf(stderr, "[!] Failed to get 2FA Code in 60s. Exiting...\n");
                    exit(0);
                }
                char *path = strcat_b(args_info.base_dir_arg, "/2fa.txt");
                if (file_exists(path)) {
                    FILE *fp = fopen(path, "r");
                    fscanf(fp, "%6s", amPassword + passLen);
                    remove(path);
                    fprintf(stderr, "[!] Code file detected! Logging in...\n");
                    break;
                } else {
                    sleep(3);
                    count++;
                }
            }
        } else {
            printf("2FA code: ");
            scanf("%6s", amPassword + passLen);
        }
    }

    uint8_t *const ptr = malloc(80);
    memset(ptr + 8, 0, 16);
    *(void **)(ptr) =
        &_ZTVNSt6__ndk120__shared_ptr_emplaceIN17storeservicescore19CredentialsResponseENS_9allocatorIS2_EEEE +
        2;
    struct shared_ptr credResp = {.obj = ptr + 24, .ctrl_blk = ptr};
    _ZN17storeservicescore19CredentialsResponseC1Ev(credResp.obj);

    DRM_DEBUG("[.] credential payload lengths: username=%zu password=%zu\n", amUsername ? strlen(amUsername) : 0, amPassword ? strlen(amPassword) : 0);
    union std_string username = new_std_string(cancelled ? "" : amUsername);
    _ZN17storeservicescore19CredentialsResponse11setUserNameERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        credResp.obj, &username);

    union std_string password = new_std_string(cancelled ? "" : amPassword);
    _ZN17storeservicescore19CredentialsResponse11setPasswordERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        credResp.obj, &password);

    _ZN17storeservicescore19CredentialsResponse15setResponseTypeENS0_12ResponseTypeE(
        credResp.obj, cancelled ? 0 : 2);
    /* 2 = the second (OK) button, 0 = the first (Cancel) button: AuthenticateFlow::_buttonActionForResponseType
     * maps them to the dialog's buttons, and 0 ends the flow as cancelled. 1 would read as "no answer". */

    _ZN20androidstoreservices28AndroidPresentationInterface25handleCredentialsResponseERKNSt6__ndk110shared_ptrIN17storeservicescore19CredentialsResponseEEE(
        apInf.obj, &credResp);
}


void drm_init_internal(void) {
    // srand(time(0));

    // raise(SIGSTOP);
    DRM_DEBUG("[+] starting...\n");
    setenv("ANDROID_DNS_MODE", "local", 1);
    if (args_info.proxy_given) {
        DRM_DEBUG("[+] Using proxy %s\n", args_info.proxy_arg);
        setenv("all_proxy", args_info.proxy_arg, 1);
    }

    static const char *resolvers[2] = {"1.1.1.1", "8.8.8.8"};
    _resolv_set_nameservers_for_net(0, resolvers, 2, ".");

    // static char android_id[16];
    // for (int i = 0; i < 16; ++i) {
    //     android_id[i] = "0123456789abcdef"[rand() % 16];
    // }
    drm_lib_phase("PHASE_DEVICE_STRINGS");
    union std_string conf1 = new_std_string(device_infos[8]);
    union std_string conf2 = new_std_string("");
    DRM_DEBUG("[trace] before FootHillConfig\n");
    drm_lib_phase("PHASE_FOOTHILL_CONFIG");
    _ZN14FootHillConfig6configERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE(
        &conf1);
    DRM_DEBUG("[trace] after FootHillConfig\n");

    // union std_string root = new_std_string("/");
    // union std_string natLib = new_std_string("/system/lib64/");
    // void *foothill = malloc(120);
    // _ZN8FootHillC2ERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES8_(
    //     foothill, &root, &natLib);
    // _ZN8FootHill24defaultContextIdentifierEv(foothill);

    DRM_DEBUG("[trace] before DeviceGUID::instance\n");
    drm_lib_phase("PHASE_DEVICE_GUID");
    _ZN17storeservicescore10DeviceGUID8instanceEv(&g_GUID);
    DRM_DEBUG("[trace] after DeviceGUID::instance obj=%p\n", g_GUID.obj);

    static uint8_t ret[88];
    static unsigned int conf3 = 29;
    static uint8_t conf4 = 1;
    DRM_DEBUG("[trace] before DeviceGUID::configure\n");
    drm_lib_phase("PHASE_DEVICE_GUID_CONFIG");
    _ZN17storeservicescore10DeviceGUID9configureERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_RKjRKb(
        &ret, g_GUID.obj, &conf1, &conf2, &conf3, &conf4);
    DRM_DEBUG("[trace] after DeviceGUID::configure\n");
}

void install_request_context_callbacks(void *cfg);

struct shared_ptr drm_init_ctx(void) {
    DRM_DEBUG("[+] initializing ctx...\n");
    drm_lib_phase("PHASE_CONTEXT_PATH");
    union std_string strBuf =
        new_std_string(drm_posix_path(strcat_b(args_info.base_dir_arg, "/mpl_db")));

    struct shared_ptr reqCtx;
    DRM_DEBUG("[cp1] make_shared RequestContext\n");
    drm_lib_phase("PHASE_CONTEXT_CREATE");
    _ZNSt6__ndk110shared_ptrIN17storeservicescore14RequestContextEE11make_sharedIJRNS_12basic_stringIcNS_11char_traitsIcEENS_9allocatorIcEEEEEEES3_DpOT_(
        &reqCtx, &strBuf);

    DRM_DEBUG("[cp2] setup vtable ptr arr=%p arr+2=%p\n",
        &_ZTVNSt6__ndk120__shared_ptr_emplaceIN17storeservicescore20RequestContextConfigENS_9allocatorIS2_EEEE,
        &_ZTVNSt6__ndk120__shared_ptr_emplaceIN17storeservicescore20RequestContextConfigENS_9allocatorIS2_EEEE + 2); fflush(stderr);
    static uint8_t ptr[480];
    *(void **)(ptr) =
        &_ZTVNSt6__ndk120__shared_ptr_emplaceIN17storeservicescore20RequestContextConfigENS_9allocatorIS2_EEEE +
        2;
    struct shared_ptr reqCtxCfg = {.obj = ptr + 32, .ctrl_blk = ptr};
    DRM_DEBUG("[cp3] reqCtxCfg ctrl_blk=%p obj=%p vptr=%p\n", reqCtxCfg.ctrl_blk, reqCtxCfg.obj, *(void**)ptr);

    DRM_DEBUG("[cp4] RequestContextConfigC2\n");
    drm_lib_phase("PHASE_CONTEXT_CONFIG_CREATE");
    _ZN17storeservicescore20RequestContextConfigC2Ev(reqCtxCfg.obj);
    DRM_DEBUG("[cp5] setBaseDirectoryPath\n");
    _ZN17storeservicescore20RequestContextConfig20setBaseDirectoryPathERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp6] setClientIdentifier\n");
    strBuf = new_std_string(device_infos[0]);
    _ZN17storeservicescore20RequestContextConfig19setClientIdentifierERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp7] setVersionIdentifier\n");
    strBuf = new_std_string(device_infos[1]);
    _ZN17storeservicescore20RequestContextConfig20setVersionIdentifierERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp8] setPlatformIdentifier\n");
    strBuf = new_std_string(device_infos[2]);
    _ZN17storeservicescore20RequestContextConfig21setPlatformIdentifierERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp9] setProductVersion\n");
    strBuf = new_std_string(device_infos[3]);
    _ZN17storeservicescore20RequestContextConfig17setProductVersionERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp10] setDeviceModel\n");
    strBuf = new_std_string(device_infos[4]);
    _ZN17storeservicescore20RequestContextConfig14setDeviceModelERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp11] setBuildVersion\n");
    strBuf = new_std_string(device_infos[5]);
    _ZN17storeservicescore20RequestContextConfig15setBuildVersionERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp12] setLocaleIdentifier\n");
    strBuf = new_std_string(device_infos[6]);
    _ZN17storeservicescore20RequestContextConfig19setLocaleIdentifierERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);
    DRM_DEBUG("[cp13] setLanguageIdentifier\n");
    strBuf = new_std_string(device_infos[7]);
    _ZN17storeservicescore20RequestContextConfig21setLanguageIdentifierERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtxCfg.obj, &strBuf);

    /* Builds that expect host callbacks (4.9.x/5.x) get them here; a no-op when the libs export no such setters. */
    drm_lib_phase("PHASE_CONTEXT_CALLBACKS");
    install_request_context_callbacks(reqCtxCfg.obj);

    DRM_DEBUG("[cp14] RequestContextManager::configure\n");
    drm_lib_phase("PHASE_CONTEXT_MANAGER");
    _ZN21RequestContextManager9configureERKNSt6__ndk110shared_ptrIN17storeservicescore14RequestContextEEE(
        &reqCtx);
    DRM_DEBUG("[cp15] RequestContext::init\n");
    static uint8_t buf[88];
    drm_lib_phase("PHASE_CONTEXT_INIT");
    _ZN17storeservicescore14RequestContext4initERKNSt6__ndk110shared_ptrINS_20RequestContextConfigEEE(
        &buf, reqCtx.obj, &reqCtxCfg);
    DRM_DEBUG("[cp16] setFairPlayDirectoryPath\n");
    strBuf = new_std_string(drm_posix_path(args_info.base_dir_arg));
    drm_lib_phase("PHASE_CONTEXT_FAIRPLAY_PATH");
    _ZN17storeservicescore14RequestContext24setFairPlayDirectoryPathERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(
        reqCtx.obj, &strBuf);

    DRM_DEBUG("[cp17] make_shared AndroidPresentationInterface\n");
    drm_lib_phase("PHASE_PRESENTATION_CREATE");
    _ZNSt6__ndk110shared_ptrIN20androidstoreservices28AndroidPresentationInterfaceEE11make_sharedIJEEES3_DpOT_(
        &apInf);

    DRM_DEBUG("[cp18] setDialogHandler\n");
    _ZN20androidstoreservices28AndroidPresentationInterface16setDialogHandlerEPFvlNSt6__ndk110shared_ptrIN17storeservicescore14ProtocolDialogEEENS2_INS_36AndroidProtocolDialogResponseHandlerEEEE(
        apInf.obj, &dialogHandler);

    DRM_DEBUG("[cp19] setCredentialsHandler\n");
    _ZN20androidstoreservices28AndroidPresentationInterface21setCredentialsHandlerEPFvNSt6__ndk110shared_ptrIN17storeservicescore18CredentialsRequestEEENS2_INS_33AndroidCredentialsResponseHandlerEEEE(
        apInf.obj, &credentialHandler);

    DRM_DEBUG("[cp20] setPresentationInterface\n");
    drm_lib_phase("PHASE_PRESENTATION_BIND");
    _ZN17storeservicescore14RequestContext24setPresentationInterfaceERKNSt6__ndk110shared_ptrINS_21PresentationInterfaceEEE(
        reqCtx.obj, &apInf);

    DRM_DEBUG("[cp21] init_ctx done\n");
    return reqCtx;
}

extern uint8_t endLeaseCallback[32];
extern uint8_t pbErrCallback[32];
extern void hybris_init_callbacks(void);
extern void  start_recovery_thread(void);
extern int   is_recovery_active(void);
/* Returns current RecoveryState as int: 0=Running 1=Scheduled 2=Refreshing 3=Failed */
extern int   get_recovery_state(void);

int drm_auth_was_cancelled(void) { return g_auth_cancelled; }

int drm_prepare_auth_flow(struct shared_ptr context) {
    struct shared_ptr flow = {0};
    drm_lib_phase("PHASE_LOGIN_FLOW_CREATE");
    _ZNSt6__ndk110shared_ptrIN17storeservicescore16AuthenticateFlowEE11make_sharedIJRNS0_INS1_14RequestContextEEEEEES3_DpOT_(&flow, &context);
    return flow.obj ? 0 : -1;
}

#ifndef _WIN32
__attribute__((visibility("hidden")))
#endif
uint8_t mygo_native_account_login(struct shared_ptr reqCtx) {
    DRM_DEBUG("[+] logging in...\n");
    g_last_auth_error[0] = '\0';
    g_auth_cancelled = 0;
    g_last_dialog[0] = '\0';
    struct shared_ptr flow;
    drm_lib_phase("PHASE_LOGIN_FLOW_CREATE");
    _ZNSt6__ndk110shared_ptrIN17storeservicescore16AuthenticateFlowEE11make_sharedIJRNS0_INS1_14RequestContextEEEEEES3_DpOT_(
        &flow, &reqCtx);
    drm_lib_phase("PHASE_LOGIN_FLOW_RUN");
    _ZN17storeservicescore16AuthenticateFlow3runEv(flow.obj);
    drm_lib_phase("PHASE_LOGIN_FLOW_RESPONSE");
    struct shared_ptr *resp =
        _ZNK17storeservicescore16AuthenticateFlow8responseEv(flow.obj);
    if (resp == NULL || resp->obj == NULL) {
        mygo_native_diagnostic("login_empty_response", 1);
        snprintf(g_last_auth_error, sizeof(g_last_auth_error), "Apple did not answer the sign-in request");
        return 0;
    }
    drm_lib_phase("PHASE_LOGIN_RESPONSE_TYPE");
    const int respType =
        _ZNK17storeservicescore20AuthenticateResponse12responseTypeEv(
            resp->obj);
    mygo_native_diagnostic("login_response_type", respType);
    if (respType != 6) {
        const char *customer_msg = std_string_data(
            _ZNK17storeservicescore20AuthenticateResponse15customerMessageEv(resp->obj));
        if (customer_msg && *customer_msg) {
            fprintf(stderr, "[!] server message: %s\n", customer_msg);
            snprintf(g_last_auth_error, sizeof(g_last_auth_error), "%s", customer_msg);
        }
        if (g_last_dialog[0])
            snprintf(g_last_auth_error, sizeof(g_last_auth_error), "%s", g_last_dialog);

        drm_lib_phase("PHASE_LOGIN_RESPONSE_ERROR");
        struct shared_ptr *err = _ZNK17storeservicescore20AuthenticateResponse5errorEv(resp->obj);
        if (err != NULL && err->obj != NULL) {
            int code = store_error_code(err->obj);
            mygo_native_diagnostic("login_error_code", code);
            mygo_capture_error_details(err->obj);
            const char *what = _ZNK17storeservicescore19StoreErrorCondition4whatEv(err->obj);
            fprintf(stderr, "[!] auth error: code=%d, message=%s\n", code, what ? what : "none");
            if (!g_last_auth_error[0])
                snprintf(g_last_auth_error, sizeof(g_last_auth_error), "Apple rejected the sign-in");
        } else {

            fprintf(stderr, "[!] auth failed: response type %d\n", respType);
            if (!g_last_auth_error[0])
                snprintf(g_last_auth_error, sizeof(g_last_auth_error), "Apple rejected the sign-in");
        }
    }
    if (g_auth_cancelled && respType != 6)
        snprintf(g_last_auth_error, sizeof(g_last_auth_error), "Sign-in cancelled");
    if (respType == 6) {
        /* Only a successful sign-in replaces the old tokens: a wrong password must not sign the
         * existing session out. */
        remove(strcat_b(args_info.base_dir_arg, "/STOREFRONT_ID"));
        remove(strcat_b(args_info.base_dir_arg, "/MUSIC_TOKEN"));
    }
    return respType == 6;
    // struct shared_ptr subStatMgr;
    // _ZN20androidstoreservices30SVSubscriptionStatusMgrFactory6createEv(&subStatMgr);
    // struct shared_ptr data;
    // int method = 2;
    // _ZN20androidstoreservices27SVSubscriptionStatusMgrImpl33checkSubscriptionStatusFromSourceERKNSt6__ndk110shared_ptrIN17storeservicescore14RequestContextEEERKNS_23SVSubscriptionStatusMgr26SVSubscriptionStatusSourceE(&data,
    // subStatMgr.obj, &reqCtx, &method);
    // return 1;
}

static inline uint8_t readfull(const int connfd, void *const buf,
                               const size_t size) {
    size_t red = 0;
    while (size > red) {
        const ssize_t b = read(connfd, ((uint8_t *)buf) + red, size - red);
        if (b <= 0)
            return 0;
        red += b;
    }
    return 1;
}

static inline void writefull(const int connfd, void *const buf,
                             const size_t size) {
    size_t red = 0;
    while (size > red) {
        const ssize_t b = write(connfd, ((uint8_t *)buf) + red, size - red);
        if (b <= 0) {
            perror("write");
            break;
        }
        red += b;
    }
}

void *FHinstance = NULL;   /* SVFootHillSessionCtrl 单例 (会话持有者) */
void *preshareCtx = NULL;  /* prefetch 上下文缓存 (adam=="0" 时复用) */

/*
 * 派生某 (adam, uri) 的 kdContext (解密上下文)。
 *
 * 流程:
 *   getPersistentKey() 从 Apple 获取持久密钥 (SVFootHillPKey, 首个字段 ckc=contentKey,
 *   离线场景由服务端账户派生) → decryptContext(persistK) 得到 SVFootHillPContext →
 *   .kdContext() 返回实际 kdContext 指针。
 *
 * 注意:
 *   - 返回的是 void** (指向 kdContext 指针), 调用方需解引用 (如 NfcR(*kdContext,...))。
 *   - adam=="0" 走 prefetch 缓存路径。
 *   - 每次调用都会重新 getPersistentKey (contentKey 每次会话会变),
 *     但 decryptContext 派生的 kdContext 是 per-track 稳定的。
 */
void *getKdContext(const char *const adam,
                                 const char *const uri) {
    uint8_t isPreshare = (strcmp("0", adam) == 0);

    /* Fast-path: return cached preshare context if available.
     * Lock only long enough to read the pointer — the long FairPlay
     * network operations below must NOT be performed under this lock,
     * or the recovery worker would block all decryption during reacquisition. */
    if (isPreshare) {
        pthread_mutex_lock(&g_ctx_mutex);
        void *cached = preshareCtx;
        pthread_mutex_unlock(&g_ctx_mutex);
        if (cached != NULL)
            return cached;
    }

#ifdef _WIN32
    /* The Android key-session path assumes a device token exists. If token
     * acquisition failed, it can throw from the guest library while trying
     * to negotiate a key. Fail the request cleanly and let auth recover. */
    if (g_dev_token == NULL || g_dev_token[0] == '\0') {
        fprintf(stderr, "[drm] key context unavailable: device token is missing\n");
        return NULL;
    }
    /* Do not enter the Android key-session path until Windows has a live
     * FairPlay subscription status. On an empty status vector the guest
     * library throws while processing the placeholder startup key and its
     * unwinder crashes the host process. */
    if (!offlineFlag) {
        fprintf(stderr, "[drm] key context unavailable: Windows FairPlay subscription is not active\n");
        return NULL;
    }
#endif
    DRM_DEBUG("[.] adamId: %s, uri: %s\n", adam, uri);

    union std_string defaultId = new_std_string(adam);
    union std_string keyUri = new_std_string(uri);
    union std_string keyFormat =
        new_std_string("com.apple.streamingkeydelivery");
    union std_string keyFormatVer = new_std_string("1");
    union std_string serverUri = new_std_string(
        "https://play.itunes.apple.com/WebObjects/MZPlay.woa/music/fps");
    union std_string protocolType = new_std_string("simplified");
    union std_string fpsCert = new_std_string(fairplayCert);

    struct shared_ptr persistK = {.obj = NULL};
    _ZN21SVFootHillSessionCtrl16getPersistentKeyERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES8_S8_S8_S8_S8_S8_S8_(
        &persistK, FHinstance, &defaultId, &defaultId, &keyUri, &keyFormat,
        &keyFormatVer, &serverUri, &protocolType, &fpsCert);

    if (persistK.obj == NULL)
        return NULL;

    struct shared_ptr SVFootHillPContext;
    _ZN21SVFootHillSessionCtrl14decryptContextERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEERKN11SVDecryptor15SVDecryptorTypeERKb(
        &SVFootHillPContext, FHinstance, persistK.obj);

    if (SVFootHillPContext.obj == NULL)
        return NULL;

    void *kdContext =
        *_ZNK18SVFootHillPContext9kdContextEv(SVFootHillPContext.obj);

    /* Store result under lock so the recovery worker sees a consistent value
     * if it concurrently resets preshareCtx to NULL. */
    if (kdContext != NULL && isPreshare) {
        pthread_mutex_lock(&g_ctx_mutex);
        preshareCtx = kdContext;
        pthread_mutex_unlock(&g_ctx_mutex);
    }

    return kdContext;
}

/*
 * 刷新解密会话: 重新请求播放租约 + 重置所有上下文 + 重建 prefetch 上下文。
 * 在 40020 key server 捕获 content 模板前调用, 把 FHinstance 会话归一化到
 * 与真实解密流程一致的状态 (否则 standalone 的 ctx/r1_entry 会不一致)。
 */
/* Bumped on every recovery refresh so callers can drop cached key contexts. */
volatile unsigned g_decrypt_epoch = 0;

/* Serialises every call into Apple's FairPlay code (key opens, sample decrypts,
 * this reset), as handle() does by serving one connection at a time. Holding it
 * here also means no decrypt can run on a context resetAllContexts() is freeing. */
pthread_mutex_t g_fp_call_mutex = PTHREAD_MUTEX_INITIALIZER;

void refresh_decrypt_ctx(void) {
    uint8_t autom = 1;
    pthread_mutex_lock(&g_fp_call_mutex);
    __atomic_add_fetch(&g_decrypt_epoch, 1, __ATOMIC_SEQ_CST);

    /* Request a new playback lease from Apple. */
    _ZN22SVPlaybackLeaseManager12requestLeaseERKb(leaseMgr, &autom);

    /* Tear down all cached FairPlay key contexts so fresh keys are derived. */
    _ZN21SVFootHillSessionCtrl16resetAllContextsEv(FHinstance);

    /* Invalidate the preshare cache under lock before rebuilding it.
     * Any concurrent getKdContext() call will miss the cache and fall through
     * to a full key derivation — correct behaviour during recovery. */
    pthread_mutex_lock(&g_ctx_mutex);
    preshareCtx = NULL;
    pthread_mutex_unlock(&g_ctx_mutex);

    /* Rebuild the preshare context.  getKdContext() will write the new pointer
     * under g_ctx_mutex internally. */
    getKdContext("0", "skd://itunes.apple.com/P000000000/s1/e1");

    pthread_mutex_unlock(&g_fp_call_mutex);
    fprintf(stderr, "[!] refreshed context\n");
}

/* Called by the recovery worker to determine whether reacquisition produced
 * a usable decrypt context.  Reads preshareCtx under g_ctx_mutex. */
int is_preshare_ctx_ready(void) {
    pthread_mutex_lock(&g_ctx_mutex);
    int ready = (preshareCtx != NULL);
    pthread_mutex_unlock(&g_ctx_mutex);
    return ready;
}

/*
 * 10020 样本解密服务主循环 (与 main.go 测试协议对应):
 *   外层按 (adam, uri) 建立解密上下文 (每首歌一次连接, 每首歌 prefetch+content 两轮),
 *   内层循环收 [4B LE size][密文] → NfcR 解密 → 写回等长明文, size<=0 结束内层。
 * 协议:
 *   [1B len]["0"] + [1B len][prefetchKey]           → prefetch 上下文
 *   [4B size][sample0 密文] → 明文
 *   {0,0,0,0}                                        → 内层 size=0, 回外层
 *   [1B len][adamID] + [1B len][contentKeyURI]      → content 上下文
 *   [4B size][sample1 密文] → 明文
 *   {0,0,0,0,0}                                      → 收尾关闭
 */
void handle(const int connfd) {
    while (1) {
        /* Fail fast during lease recovery: avoid queuing FairPlay key-
         * delivery requests to Apple's servers while the recovery worker
         * is already performing a refresh cycle.  The client receives an
         * EOF/broken-pipe and should retry after a brief pause. */
        if (is_recovery_active()) {
            fprintf(stderr, "[.] decrypt request refused: lease recovery in progress\n");
            return;
        }

        uint8_t adamSize;
        if (!readfull(connfd, &adamSize, sizeof(uint8_t)))
            return;
        if (adamSize <= 0)
            return;

        char adam[adamSize + 1];
        if (!readfull(connfd, adam, adamSize))
            return;
        adam[adamSize] = '\0';

        uint8_t uri_size;
        if (!readfull(connfd, &uri_size, sizeof(uint8_t)))
            return;

        char uri[uri_size + 1];
        if (!readfull(connfd, uri, uri_size))
            return;
        uri[uri_size] = '\0';

        void **const kdContext = getKdContext(adam, uri);
        if (kdContext == NULL)
            return;

        while (1) {
            uint32_t size;
            if (!readfull(connfd, &size, sizeof(uint32_t))) {
                perror("read");
                return;
            }

            if (size <= 0)
                break;

            void *sample = malloc(size);
            if (sample == NULL) {
                perror("malloc");
                return;
            }
            if (!readfull(connfd, sample, size)) {
                free(sample);
                perror("read");
                return;
            }

            NfcRKVnxuKZy04KWbdFu71Ou(*kdContext, 5, sample, sample, size);
            writefull(connfd, sample, size);
            free(sample);
        }
    }
}

extern uint8_t handle_cpp(int);

inline static int new_socket() {
    const int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (fd == -1) {
        perror("socket");
        return EXIT_FAILURE;
    }
    const int optval = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    static struct sockaddr_in serv_addr = {.sin_family = AF_INET};
    inet_pton(AF_INET, args_info.host_arg, &serv_addr.sin_addr);
    serv_addr.sin_port = htons(args_info.decrypt_port_arg);
    if (bind(fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) {
        perror("bind");
        return EXIT_FAILURE;
    }

    if (listen(fd, 5) == -1) {
        perror("listen");
        return EXIT_FAILURE;
    }

    fprintf(stderr, "[!] listening %s:%d\n", args_info.host_arg, args_info.decrypt_port_arg);
    // close(STDOUT_FILENO);

    static struct sockaddr_in peer_addr;
    static socklen_t peer_addr_size = sizeof(peer_addr);
    while (1) {
        const int connfd = accept4(fd, (struct sockaddr *)&peer_addr,
                                   &peer_addr_size, SOCK_CLOEXEC);
        if (connfd == -1) {
            if (errno == ENETDOWN || errno == EPROTO || errno == ENOPROTOOPT ||
                errno == EHOSTDOWN || errno == ENONET ||
                errno == EHOSTUNREACH || errno == EOPNOTSUPP ||
                errno == ENETUNREACH)
                continue;
            perror("accept4");
            return EXIT_FAILURE;
        }

        if (!handle_cpp(connfd)) {
            uint8_t autom = 1;
            _ZN22SVPlaybackLeaseManager12requestLeaseERKb(leaseMgr, &autom);
        }
        // if (sigsetjmp(catcher.env, 0) == 0) {
        //     catcher.do_jump = 1;
        //     handle(connfd);
        // }
        // catcher.do_jump = 0;

        if (close(connfd) == -1) {
            perror("close");
            return EXIT_FAILURE;
        }
    }
}


/* out_key: if non-NULL, receives a strdup'd downloadKey string (caller must free).
 * Set to NULL on failure or if the asset carries no downloadKey. */
const char* get_m3u8_method_download(struct shared_ptr reqCtx, unsigned long adam, char **out_key) {
    if (out_key) *out_key = NULL;
    void *purchase_request = malloc(1024);
    _ZN17storeservicescore15PurchaseRequestC2ERKNSt6__ndk110shared_ptrINS_14RequestContextEEE(purchase_request, &reqCtx);
    _ZN17storeservicescore15PurchaseRequest23setProcessDialogActionsEb(purchase_request, 1);
    union std_string urlBagKey = new_std_string("subDownload");
    _ZN17storeservicescore15PurchaseRequest12setURLBagKeyERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(purchase_request, &urlBagKey);
    char *buyParametersStr = malloc(128);
    sprintf(buyParametersStr, "salableAdamId=%lu&price=0&pricingParameters=SUBS&productType=S", adam);
    union std_string buyParameters = new_std_string(buyParametersStr);
    _ZN17storeservicescore15PurchaseRequest16setBuyParametersERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE(purchase_request, &buyParameters);
    _ZN17storeservicescore15PurchaseRequest3runEv(purchase_request);
    struct shared_ptr *response = _ZNK17storeservicescore15PurchaseRequest8responseEv(purchase_request);
    struct shared_ptr *error = _ZN17storeservicescore16PurchaseResponse5errorEv(response->obj);;
    if (error->obj == NULL) {
        struct std_vector items = _ZNK17storeservicescore16PurchaseResponse5itemsEv(response->obj);
        struct shared_ptr *firstItem = items.begin;
        struct std_vector assets = _ZNK17storeservicescore12PurchaseItem6assetsEv(firstItem->obj);
        struct shared_ptr *lastAsset = (struct shared_ptr *)assets.end - 1;
        union std_string *url_str = malloc(sizeof(union std_string));
        _ZNK17storeservicescore13PurchaseAsset3URLEv(url_str, lastAsset->obj);
        const char *url = std_string_data(url_str);
        if (url) {
            char *result = strdup(url);
            free(url_str);
            if (out_key) {
                union std_string *key_str = malloc(sizeof(union std_string));
                _ZNK17storeservicescore13PurchaseAsset11downloadKeyEv(key_str, lastAsset->obj);
                const char *key = std_string_data(key_str);
                if (key && *key) {
                    *out_key = strdup(key);
                    DRM_DEBUG("[.] downloadKey for %lu: %.16s...\n", adam, *out_key);
                } else {
                    DRM_DEBUG("[.] downloadKey for %lu: empty\n", adam);
                }
                free(key_str);
            }
            return result;
        }
    }
    return NULL;
}


/* out_key: if non-NULL, receives a strdup'd downloadKey from the lease PlaybackAsset
 * (caller must free). NULL on failure or if the asset carries no downloadKey. */
const char* get_m3u8_method_play(uint8_t leaseMgr[16], unsigned long adam, char **out_key) {
    if (out_key) *out_key = NULL;
    union std_string HLS = new_std_string_short_mode("HLS");
    struct std_vector HLSParam = new_std_vector(&HLS);
    static uint8_t z0 = 0;
    struct shared_ptr ptr_result;
    _ZN22SVPlaybackLeaseManager12requestAssetERKmRKNSt6__ndk16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEERKb(
        &ptr_result, leaseMgr, &adam, &HLSParam, &z0
    );

    if (ptr_result.obj == NULL) {
        return NULL;
    }

    if (_ZNK23SVPlaybackAssetResponse13hasValidAssetEv(ptr_result.obj)) {
        struct shared_ptr *playbackAsset = _ZNK23SVPlaybackAssetResponse13playbackAssetEv(ptr_result.obj);
        if (playbackAsset == NULL || playbackAsset->obj == NULL) {
            return NULL;
        }

        void *playbackObj = playbackAsset->obj;

        union std_string *m3u8 = malloc(sizeof(union std_string));
        if (m3u8 == NULL) {
            return NULL;
        }
        _ZNK17storeservicescore13PlaybackAsset9URLStringEv(m3u8, playbackObj);

        if (std_string_data(m3u8) == NULL) {
            free(m3u8);
            return NULL;
        }

        const char *m3u8_str = std_string_data(m3u8);
        char *result = m3u8_str ? strdup(m3u8_str) : NULL;
        free(m3u8);

        if (result && out_key) {
            union std_string *key_str = malloc(sizeof(union std_string));
            if (key_str) {
                _ZNK17storeservicescore13PlaybackAsset11downloadKeyEv(key_str, playbackObj);
                const char *key = std_string_data(key_str);
                if (key && *key) {
                    *out_key = strdup(key);
                    DRM_DEBUG("[.] lease downloadKey for %lu: %.16s...\n", adam, *out_key);
                } else {
                    DRM_DEBUG("[.] lease downloadKey for %lu: empty\n", adam);
                }
                free(key_str);
            }
        }

        return result;
    } else {
        return NULL;
    }
}

/* Request video flavors from the lease manager matching the real Android app behavior:
 * pass all flavors as a single vector with force=true.
 * Returns strdup'd URL on success, NULL on failure. */
static const char* request_video_flavors(uint8_t leaseMgr[16], unsigned long adam,
                                         char **out_key) {
    if (out_key) *out_key = NULL;
    static const char *flavor_names[] = {"720p", "hdmv", "480p", "sdmv"};
    union std_string flavors[4];
    for (int i = 0; i < 4; i++)
        flavors[i] = new_std_string_short_mode(flavor_names[i]);
    struct std_vector flavParam = {
        .begin = flavors,
        .end = (char*)flavors + sizeof(flavors),
        .end_capacity = (char*)flavors + sizeof(flavors),
    };
    static uint8_t z1 = 1;
    struct shared_ptr ptr_result;
    _ZN22SVPlaybackLeaseManager12requestAssetERKmRKNSt6__ndk16vectorINS2_12basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEENS7_IS9_EEEERKb(
        &ptr_result, leaseMgr, &adam, &flavParam, &z1
    );

    if (ptr_result.obj == NULL) {
        fprintf(stderr, "[!] video: requestAsset NULL for %lu\n", adam);
        return NULL;
    }

    if (!(_ZNK23SVPlaybackAssetResponse13hasValidAssetEv(ptr_result.obj) & 0xFF)) {
        int ec = _ZNK23SVPlaybackAssetResponse9errorCodeEv(ptr_result.obj);
        fprintf(stderr, "[!] video: hasValidAsset=false errorCode=%d for %lu\n", ec, adam);
        return NULL;
    }

    int hv = _ZNK23SVPlaybackAssetResponse13hasValidAssetEv(ptr_result.obj);
    struct shared_ptr *playbackAsset = _ZNK23SVPlaybackAssetResponse13playbackAssetEv(ptr_result.obj);
    DRM_DEBUG("[.] video: resp=%p hasValid=%d assetPtr=%p asset.obj=%p for %lu\n",
            ptr_result.obj, hv,
            (void*)playbackAsset,
            playbackAsset ? (void*)playbackAsset->obj : NULL,
            adam);
    if (playbackAsset == NULL || playbackAsset->obj == NULL) {
        fprintf(stderr, "[!] video: playbackAsset NULL for %lu\n", adam);
        return NULL;
    }

    void *playbackObj = playbackAsset->obj;

    union std_string *url_str = malloc(sizeof(union std_string));
    if (url_str == NULL) return NULL;
    _ZNK17storeservicescore13PlaybackAsset9URLStringEv(url_str, playbackObj);

    const char *url = std_string_data(url_str);
    if (url == NULL || *url == '\0') {
        fprintf(stderr, "[!] video: URLString empty for %lu\n", adam);
        free(url_str);
        return NULL;
    }

    char *result = strdup(url);
    free(url_str);

    /* Extract downloadKey (may be empty for MV — that's OK) */
    if (result && out_key) {
        union std_string *key_str = malloc(sizeof(union std_string));
        if (key_str) {
            _ZNK17storeservicescore13PlaybackAsset11downloadKeyEv(key_str, playbackObj);
            const char *key = std_string_data(key_str);
            if (key && *key) {
                *out_key = strdup(key);
                DRM_DEBUG("[.] video: downloadKey for %lu len=%zu\n", adam, strlen(*out_key));
            } else {
                DRM_DEBUG("[.] video: downloadKey empty for %lu (expected for MV)\n", adam);
            }
            free(key_str);
        }
    }

    /* Extract sinfs and create itun decryptor for this asset */
    {
        struct std_vector sinf_vec = {0};
        _ZNK17storeservicescore13PlaybackAsset5sinfsEv(&sinf_vec, playbackObj);

        size_t sinf_count = 0;
        if (sinf_vec.begin && sinf_vec.end > sinf_vec.begin) {
            sinf_count = ((char*)sinf_vec.end - (char*)sinf_vec.begin) / sizeof(struct FairPlaySinf);
        }
        DRM_DEBUG("[.] video: sinfs count=%zu for %lu\n", sinf_count, adam);

        if (sinf_count > 0) {
            struct FairPlaySinf *sinf = (struct FairPlaySinf *)sinf_vec.begin;
            DRM_DEBUG("[.] video: sinf[0] id=%ld sinfData.obj=%p sinf2Data.obj=%p\n",
                    (long)sinf->identifier, sinf->sinfData.obj, sinf->sinf2Data.obj);

            const uint8_t *key_data = NULL;
            uint32_t key_len = 0;
            const uint8_t *iv_data = NULL;
            uint32_t iv_len = 0;

            if (sinf->sinfData.obj) {
                struct FairPlayData *fpd = (struct FairPlayData *)sinf->sinfData.obj;
                key_data = fpd->bytes_ptr;
                key_len = fpd->length;
                DRM_DEBUG("[.] video: sinfData bytes=%p len=%u\n", key_data, key_len);
            }
            if (sinf->sinf2Data.obj) {
                struct FairPlayData *fpd2 = (struct FairPlayData *)sinf->sinf2Data.obj;
                iv_data = fpd2->bytes_ptr;
                iv_len = fpd2->length;
                DRM_DEBUG("[.] video: sinf2Data bytes=%p len=%u\n", iv_data, iv_len);
            }

            if (key_data && key_len > 0) {
                int prot_type = 3;    // itun
                int track_type = 1;   // video
                uint8_t b_true = 1;
                uint8_t b_false = 0;
                struct shared_ptr new_dec = {0};

                DRM_DEBUG("[.] video: creating SVPastisDecryptor protType=%d trackType=%d keyLen=%u ivLen=%u\n",
                        prot_type, track_type, key_len, iv_len);

                _ZN18SVDecryptorFactory6createERKN11SVDecryptor15SVDecryptorTypeEPKhRKjS5_S7_RKNS0_20SVDecryptorTrackTypeERKbSC_(
                    &new_dec, &prot_type, key_data, &key_len,
                    iv_data ? iv_data : (const uint8_t*)"", &iv_len,
                    &track_type, &b_true, &b_false);

                if (new_dec.obj) {
                    DRM_DEBUG("[+] video: SVPastisDecryptor created at %p for %lu\n", new_dec.obj, adam);
                    pthread_mutex_lock(&g_itun_mutex);
                    g_itun_decryptor = new_dec;
                    g_itun_adam_id = adam;
                    pthread_mutex_unlock(&g_itun_mutex);
                } else {
                    fprintf(stderr, "[!] video: SVDecryptorFactory::create returned NULL for %lu\n", adam);
                }
            }
        }
    }

    DRM_DEBUG("[.] video: URL for %lu = %.80s...\n", adam, result);
    return result;
}

/* Request progressive MV playback matching the real Android app:
   all video flavors [720p, hdmv, 480p, sdmv] in a single vector call with force=true.
   downloadKey is empty for MV content — the file is itun-encrypted and decrypted client-side. */
const char* get_progressive_method_play(uint8_t leaseMgr[16], unsigned long adam, char **out_key) {
    if (out_key) *out_key = NULL;
    const char *url = request_video_flavors(leaseMgr, adam, out_key);
    if (url) {
        DRM_DEBUG("[.] progressive: got URL for %lu\n", adam);
        return url;
    }
    fprintf(stderr, "[!] progressive: no valid asset for %lu\n", adam);
    return NULL;
}

/*
 * 20020 M3U8 流地址服务: 收 [1B len][adamId 数字串] → 返回该歌的 M3U8 URL + 换行。
 * 由 get_m3u8_method_download/play 经 PlaybackAsset 从 Apple 获取。
 */

void handle_m3u8(const int connfd) {
    while (1)
    {
        uint8_t adamSize;
        if (!readfull(connfd, &adamSize, sizeof(uint8_t))) {
            return;
        }
        if (adamSize <= 0) {
            return;
        }
        char adam[adamSize];
        for (int i=0; i<adamSize; i=i+1) {
            readfull(connfd, &adam[i], sizeof(uint8_t));
        }
        char *ptr;
        unsigned long adamID = strtoul(adam, &ptr, 10);
        const char *m3u8;

        /* During lease recovery the decrypt context is being rebuilt.
         * Return an empty line (same as a failed asset request) so the
         * client can detect the condition and retry rather than waiting
         * on a network call that will fail anyway. */
        if (is_recovery_active()) {
            fprintf(stderr, "[.] m3u8 request refused: lease recovery in progress\n");
            writefull(connfd, "\n", 1);
            continue;
        }

        if (offlineFlag) {
            m3u8 = get_m3u8_method_download(reqCtx, adamID, NULL);
        } else {
            m3u8 = get_m3u8_method_play(leaseMgr, adamID, NULL);
        }
        if (m3u8 == NULL) {
            fprintf(stderr, "[.] failed to get m3u8 of adamId: %ld\n", adamID);
            writefull(connfd, "\n", sizeof("\n"));
        } else {
            DRM_DEBUG("[.] m3u8 adamId: %ld, url: %s\n", adamID, m3u8);
            char *with_newline = malloc(strlen(m3u8) + 2);
            if (with_newline) {
                strcpy(with_newline, m3u8);
                strcat(with_newline, "\n");
                writefull(connfd, with_newline, strlen(with_newline));
                free(with_newline);
            }
            free((void *)m3u8);
        }
    }
}

static inline void *new_socket_m3u8(void *args) {
    const int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (fd == -1) {
        perror("socket");
    }
    const int optval = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    static struct sockaddr_in serv_addr = {.sin_family = AF_INET};
    inet_pton(AF_INET, args_info.host_arg, &serv_addr.sin_addr);
    serv_addr.sin_port = htons(args_info.m3u8_port_arg);
    if (bind(fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) {
        perror("bind");
    }

    if (listen(fd, 5) == -1) {
        perror("listen");
    }

    fprintf(stderr, "[!] listening m3u8 request on %s:%d\n", args_info.host_arg, args_info.m3u8_port_arg);
    // close(STDOUT_FILENO);

    static struct sockaddr_in peer_addr;
    static socklen_t peer_addr_size = sizeof(peer_addr);
    while (1) {
        const int connfd = accept4(fd, (struct sockaddr *)&peer_addr,
                                   &peer_addr_size, SOCK_CLOEXEC);
        if (connfd == -1) {
            if (errno == ENETDOWN || errno == EPROTO || errno == ENOPROTOOPT ||
                errno == EHOSTDOWN || errno == ENONET ||
                errno == EHOSTUNREACH || errno == EOPNOTSUPP ||
                errno == ENETUNREACH)
                continue;
            perror("accept4");
            
        }

        handle_m3u8(connfd);

        if (close(connfd) == -1) {
            perror("close");
        }
    }
}

/* ==================== Key delivery HTTP service ====================
 * GET /key?adamId=<id>[&uri=<skd://...>]
 *   返回 { "adamId":..., "keyUri":..., "contentKey":... }
 *   contentKey = 离线 persistentKey（服务端持账号派生，不含账号凭据）
 */

static char *url_decode(const char *src) {
    size_t len = strlen(src);
    char *dst = malloc(len + 1);
    if (!dst) return NULL;
    size_t j = 0;
    for (size_t i = 0; i < len; i++) {
        if (src[i] == '%' && i + 2 < len && isxdigit((unsigned char)src[i+1]) && isxdigit((unsigned char)src[i+2])) {
            char hi = src[i+1], lo = src[i+2];
            int h = (hi <= '9') ? hi - '0' : (tolower((unsigned char)hi) - 'a' + 10);
            int l = (lo <= '9') ? lo - '0' : (tolower((unsigned char)lo) - 'a' + 10);
            dst[j++] = (char)((h << 4) | l);
            i += 2;
        } else {
            dst[j++] = src[i];
        }
    }
    dst[j] = '\0';
    return dst;
}

static char *get_content_key(const char *adamId, const char *keyUri) {
    union std_string defaultId = new_std_string(adamId);
    union std_string keyUriStr = new_std_string(keyUri);
    union std_string keyFormat = new_std_string("com.apple.streamingkeydelivery");
    union std_string keyFormatVer = new_std_string("1");
    union std_string serverUri = new_std_string("https://play.itunes.apple.com/WebObjects/MZPlay.woa/music/fps");
    union std_string protocolType = new_std_string("simplified");
    union std_string fpsCertStr = new_std_string(fairplayCert);

    struct shared_ptr persistK = {.obj = NULL};
    _ZN21SVFootHillSessionCtrl16getPersistentKeyERKNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES8_S8_S8_S8_S8_S8_S8_(
        &persistK, FHinstance, &defaultId, &defaultId, &keyUriStr, &keyFormat,
        &keyFormatVer, &serverUri, &protocolType, &fpsCertStr);

    if (persistK.obj == NULL)
        return NULL;

    /* SVFootHillPKey: first field is std::string ckc (= contentKey when offline) */
    union std_string *pkey = (union std_string *)persistK.obj;
    const char *data = std_string_data(pkey);
    if (!data || !*data) return NULL;
    return strdup(data);
}

static void key_json_error(const int connfd, const char *code, const char *msg) {
    size_t body_len = strlen("{\"error\":\"\",\"code\":\"\"}") + strlen(msg) + strlen(code) + 4;
    char *body = malloc(body_len);
    if (!body) return;
    snprintf(body, body_len, "{\"error\":\"%s\",\"code\":\"%s\"}", msg, code);
    char *resp = malloc(512);
    if (!resp) { free(body); return; }
    snprintf(resp, 512, "HTTP/1.1 %s\r\nContent-Type: application/json\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             strcmp(code, "400") == 0 ? "400 Bad Request" : "500 Internal Server Error", strlen(body));
    writefull(connfd, resp, strlen(resp));
    writefull(connfd, body, strlen(body));
    free(resp); free(body);
}


/* =====================================================================
 * content 解密模板捕获 (供 40020 key server 返回)
 * ---------------------------------------------------------------------
 * 背景: 纯 Python 离线解密器需要 (ctx, st_init, r1_entry) 三件套才能解密
 *   content 样本。ctx = kdContext(0x8000B)，st_init = R1 入口初始状态
 *   (rbp-0x2000 起 0x2100B)，r1_entry = R1 入口寄存器 (rcx/rax/rdx/r9/rbp)。
 *   这些只在 R1 函数 (libCoreLSKD+0x1d5709) 入口那一刻存在，因此用 Dobby
 *   在该入口下 hook，主动触发一次 NfcR 解密来捕获。
 *
 * R1 入口语义 (sub_1D5709, 见 decryption/src/round1_mid.py):
 *   第一条指令 `movzx ecx, byte ptr [r9+rcx+2EE0h]`:
 *     r9  = ctx 基址 (kdContext)          → dump 0x8000B
 *     rcx = S-box 索引 (随密钥变化)        → r1_entry
 *     rax = 另一入口常量 (随密钥变化)      → r1_entry
 *     rsi = 块游标 (block0 时 == 8)       → 用于过滤只捕获 block 0
 *     rbp = R1 栈帧 → rbp-0x2000 为初始状态 → dump 0x2100B
 * ===================================================================== */
static volatile void *g_cap_target = NULL;   /* 预留 (原按 r9 匹配, 后改为按 block0) */
static volatile int g_cap_armed = 0;         /* 1=捕获窗口开启 */
static volatile int g_cap_done = 0;          /* 1=已成功捕获 */
static uint8_t g_cap_ctx[0x8000];            /* 捕获的 ctx */
static uint8_t g_cap_state[0x2100];          /* 捕获的原始 state (rbp-0x2000) */
static uint64_t g_cap_rcx, g_cap_rax, g_cap_rdx, g_cap_r9, g_cap_rbp;
static int g_r1_hooked = 0;                  /* R1 hook 是否已安装 */

/* R1 入口 Dobby hook 回调: 捕获 block0 的 ctx/state/寄存器到全局缓冲 */
static void r1_capture_cb(void *address, DobbyRegisterContext *ctx) {
    uint64_t r9 = ctx->general.regs.r9;
    if (!g_cap_armed || g_cap_done) return;
    if ((ctx->general.regs.rsi & 0xff) != 8) return;  /* 只捕获 block 0 (rsi==8) */
    uint64_t rbp = ctx->general.regs.rbp;
    memcpy(g_cap_ctx, (void *)(uintptr_t)r9, 0x8000);
    memcpy(g_cap_state, (void *)(uintptr_t)(rbp - 0x2000), 0x2100);
    g_cap_rcx = ctx->general.regs.rcx;
    g_cap_rax = ctx->general.regs.rax;
    g_cap_rdx = ctx->general.regs.rdx;
    g_cap_r9 = r9;
    g_cap_rbp = rbp;
    g_cap_done = 1;
}

/* 返回 libCoreLSKD.so 的运行时加载基址 (失败返回 0) */
static uintptr_t get_lib_core_lskd_base(void) {
    FILE *f = fopen("/proc/self/maps", "r");
    if (!f) return 0;
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof line, f)) {
        if (!strstr(line, "libCoreLSKD.so")) continue;
        unsigned long start, off;
        if (sscanf(line, "%lx-%*lx %*4s %lx", &start, &off) == 2 && off == 0) {
            base = start;
            break;
        }
    }
    fclose(f);
    return base;
}

/* 在 libCoreLSKD+0x1d5709 (R1 入口) 安装 Dobby hook (仅一次) */
static void setup_r1_hook(void) {
    if (g_r1_hooked) return;
    uintptr_t base = get_lib_core_lskd_base();
    if (!base) { fprintf(stderr, "[!] libCoreLSKD not loaded\n"); return; }
    void *r1 = (void *)(base + 0x1d5709);
    if (DobbyInstrument(r1, r1_capture_cb) == 0) {
        g_r1_hooked = 1;
        DRM_DEBUG("[+] R1 hook installed @ %p (base 0x%lx)\n", r1, base);
    } else {
        fprintf(stderr, "[!] R1 hook install failed @ %p\n", r1);
    }
}

/*
 * 捕获某 (adam, uri) 的 content 解密模板: ctx + 原始 state + R1 入口寄存器。
 *
 * 流程:
 *   1. (可选 with_refresh) refresh_decrypt_ctx() 复刻真实解密会话 —— 会话是
 *      安全网: 首次尝试不刷新 (实测大多成功), 失败后调用方带 refresh 重试。
 *   2. getKdContext(adam, uri) 派生 kdContext (注意: 返回值是 void**, 需解引用)
 *   3. 开启捕获窗口, 对 64B 全零 dummy 跑一次 NfcR 触发 R1 hook
 *   4. 若捕获成功, 拷贝 ctx/state/寄存器到输出; 否则返回 -1
 *
 * 返回 0 成功, -1 失败 (getKdContext 失败 / hook 未装 / R1 未触发)。
 */
static int capture_content_template(const char *adam, const char *uri,
                                    uint8_t *ctx_out, uint8_t *state_out,
                                    uint64_t *rcx, uint64_t *rax, uint64_t *rdx,
                                    uint64_t *r9, uint64_t *rbp, int with_refresh) {
    /* 会话刷新是安全网: 首次尝试不刷新, 失败后带 refresh 重试 */
    if (with_refresh) refresh_decrypt_ctx();
    void **kd_ptr = getKdContext(adam, uri);
    if (!kd_ptr || !*kd_ptr) { fprintf(stderr, "[!] getKdContext failed\n"); return -1; }
    void *kd = *kd_ptr;
    setup_r1_hook();
    if (!g_r1_hooked) return -1;
    g_cap_target = kd;
    g_cap_armed = 1;
    g_cap_done = 0;
    uint8_t dummy[64] = {0};
    NfcRKVnxuKZy04KWbdFu71Ou(kd, 5, dummy, dummy, 64);  /* 触发 R1 hook */
    g_cap_armed = 0;
    if (!g_cap_done) { fprintf(stderr, "[!] R1 capture not triggered\n"); return -1; }
    memcpy(ctx_out, g_cap_ctx, 0x8000);
    memcpy(state_out, g_cap_state, 0x2100);
    *rcx = g_cap_rcx; *rax = g_cap_rax; *rdx = g_cap_rdx;
    *r9 = g_cap_r9; *rbp = g_cap_rbp;
    return 0;
}

/* 极简 base64 编码 (无第三方依赖, 用于 JSON 响应中编码 ctx/state 二进制) */
static void b64encode(const uint8_t *in, size_t len, char *out) {
    static const char *t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    size_t i = 0, o = 0;
    for (; i + 2 < len; i += 3) {
        uint32_t v = (in[i] << 16) | (in[i+1] << 8) | in[i+2];
        out[o++] = t[(v >> 18) & 63]; out[o++] = t[(v >> 12) & 63];
        out[o++] = t[(v >> 6) & 63]; out[o++] = t[v & 63];
    }
    if (i + 1 == len) {
        uint32_t v = in[i] << 16;
        out[o++] = t[(v >> 18) & 63]; out[o++] = t[(v >> 12) & 63]; out[o++] = '='; out[o++] = '=';
    } else if (i + 2 == len) {
        uint32_t v = (in[i] << 16) | (in[i+1] << 8);
        out[o++] = t[(v >> 18) & 63]; out[o++] = t[(v >> 12) & 63];
        out[o++] = t[(v >> 6) & 63]; out[o++] = '=';
    }
    out[o] = 0;
}

/*
 * 40020 key 服务 (HTTP GET): 解析 ?adamId=&uri= 参数。
 * 返回 JSON: {adamId, keyUri, contentKey, ctx, state, rcx, rax, rdx, r9, rbp}
 *   - contentKey: 该 (adam,uri) 的 contentKey (base64 字符串)
 *   - ctx/state:  content 解密模板 (base64) — 供 Python 离线解密器
 *   - rcx/rax/rdx/r9/rbp: R1 入口寄存器 (hex)
 * 首次捕获不刷新会话, 失败后带 refresh 重试 (见 capture_content_template)。
 */
void handle_key_request(const int connfd) {
    char buffer[4096];
    ssize_t n = read(connfd, buffer, sizeof(buffer) - 1);
    if (n <= 0) return;
    buffer[n] = '\0';

    if (strncmp(buffer, "GET", 3) != 0) {
        key_json_error(connfd, "405", "method not allowed");
        return;
    }

    char *adamId = NULL;
    char *uri = NULL;
    char *query = strchr(buffer, '?');
    if (query) {
        query++;
        char *sp = strchr(query, ' ');
        if (sp) *sp = '\0';
        char *saveptr;
        char *token = strtok_r(query, "&", &saveptr);
        while (token) {
            if (strncmp(token, "adamId=", 7) == 0) {
                adamId = url_decode(token + 7);
            } else if (strncmp(token, "uri=", 4) == 0) {
                uri = url_decode(token + 4);
            }
            token = strtok_r(NULL, "&", &saveptr);
        }
    }

    if (!adamId) {
        key_json_error(connfd, "400", "missing adamId");
        return;
    }

    /* Apple Music uses a single prefetch key URI for all tracks
       (m3u8 #EXT-X-KEY). Default to it unless an explicit uri is given. */
    if (!uri) {
        uri = strdup("skd://itunes.apple.com/P000000000/s1/e1");
        if (!uri) { free(adamId); key_json_error(connfd, "500", "oom"); return; }
    }

    DRM_DEBUG("[.] key request: adamId=%s uri=%s\n", adamId, uri);
    char *contentKey = get_content_key(adamId, uri);
    if (!contentKey) {
        free(adamId); free(uri);
        key_json_error(connfd, "500", "key retrieval failed");
        return;
    }

    cJSON *root = cJSON_CreateObject();
    cJSON_AddStringToObject(root, "adamId", adamId);
    cJSON_AddStringToObject(root, "keyUri", uri);
    cJSON_AddStringToObject(root, "contentKey", contentKey);
    {
        uint8_t cap_ctx[0x8000], cap_state[0x2100];
        uint64_t rcx = 0, rax = 0, rdx = 0, r9 = 0, rbp = 0;
        int cap_ok = capture_content_template(adamId, uri, cap_ctx, cap_state,
                                              &rcx, &rax, &rdx, &r9, &rbp, 0);
        if (cap_ok != 0) {
            /* 首次失败: 带会话刷新重试 */
            fprintf(stderr, "[.] capture without refresh failed, retry with refresh\n");
            cap_ok = capture_content_template(adamId, uri, cap_ctx, cap_state,
                                              &rcx, &rax, &rdx, &r9, &rbp, 1);
        }
        if (cap_ok == 0) {
            char ctx_b64[0x8000 * 4 / 3 + 8];
            char state_b64[0x2100 * 4 / 3 + 8];
            char tmp[64];
            b64encode(cap_ctx, 0x8000, ctx_b64);
            b64encode(cap_state, 0x2100, state_b64);
            cJSON_AddStringToObject(root, "ctx", ctx_b64);
            cJSON_AddStringToObject(root, "state", state_b64);
            snprintf(tmp, sizeof(tmp), "0x%llx", (unsigned long long)rcx);
            cJSON_AddStringToObject(root, "rcx", tmp);
            snprintf(tmp, sizeof(tmp), "0x%llx", (unsigned long long)rax);
            cJSON_AddStringToObject(root, "rax", tmp);
            snprintf(tmp, sizeof(tmp), "0x%llx", (unsigned long long)rdx);
            cJSON_AddStringToObject(root, "rdx", tmp);
            snprintf(tmp, sizeof(tmp), "0x%llx", (unsigned long long)r9);
            cJSON_AddStringToObject(root, "r9", tmp);
            snprintf(tmp, sizeof(tmp), "0x%llx", (unsigned long long)rbp);
            cJSON_AddStringToObject(root, "rbp", tmp);
            DRM_DEBUG("[.] key response +ctx template (adamId=%s)\n", adamId);
        }
    }
    char *json_body = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    if (!json_body) { free(contentKey); free(adamId); free(uri); return; }

    char *http_response = malloc(1024);
    if (!http_response) { free(json_body); free(contentKey); free(adamId); free(uri); return; }
    snprintf(http_response, 1024, "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: %zu\r\nConnection: close\r\n\r\n",
             strlen(json_body));
    DRM_DEBUG("[.] key response: adamId=%s contentKey len=%zu body=%zu\n", adamId, strlen(contentKey), strlen(json_body));
    writefull(connfd, http_response, strlen(http_response));
    writefull(connfd, json_body, strlen(json_body));

    free(http_response); free(json_body); free(contentKey);
    free(adamId); free(uri);
}

static inline void *new_socket_key(void *args) {
    const int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (fd == -1) { perror("socket"); return NULL; }
    const int optval = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    static struct sockaddr_in serv_addr = {.sin_family = AF_INET};
    inet_pton(AF_INET, args_info.host_arg, &serv_addr.sin_addr);
    serv_addr.sin_port = htons(args_info.key_port_arg);
    if (bind(fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) { perror("bind"); return NULL; }
    if (listen(fd, 5) == -1) { perror("listen"); return NULL; }

    fprintf(stderr, "[!] listening key request on %s:%d\n", args_info.host_arg, args_info.key_port_arg);
    static struct sockaddr_in peer_addr;
    static socklen_t peer_addr_size = sizeof(peer_addr);
    while (1) {
        const int connfd = accept4(fd, (struct sockaddr *)&peer_addr, &peer_addr_size, SOCK_CLOEXEC);
        if (connfd == -1) {
            if (errno == ENETDOWN || errno == EPROTO || errno == ENOPROTOOPT ||
                errno == EHOSTDOWN || errno == ENONET || errno == EHOSTUNREACH ||
                errno == EOPNOTSUPP || errno == ENETUNREACH)
                continue;
            perror("accept4");
        }
        extern uint8_t handle_key_request_cpp(int);
        handle_key_request_cpp(connfd);
        if (close(connfd) == -1) { perror("close"); }
    }
}

void handle_account(const int connfd)
{
    char buffer[4096];
    ssize_t n = read(connfd, buffer, sizeof(buffer) - 1);
    if (n <= 0) {
        return;
    }
    buffer[n] = '\0';

    // Parse HTTP request (simple check for GET)
    if (strncmp(buffer, "GET", 3) != 0 && strncmp(buffer, "POST", 4) != 0) {
        const char *error_response = "HTTP/1.1 400 Bad Request\r\nContent-Type: application/json\r\nContent-Length: 0\r\n\r\n";
        writefull(connfd, (void *)error_response, strlen(error_response));
        return;
    }

    // Format JSON response body
    size_t json_size = 1024;
    char *json_body = (char *)malloc(json_size);
    if (json_body == NULL)
    {
        fprintf(stderr, "[.] failed to allocate memory for account response\n");
        const char *error_response = "HTTP/1.1 500 Internal Server Error\r\nContent-Type: application/json\r\nContent-Length: 0\r\n\r\n";
        writefull(connfd, (void *)error_response, strlen(error_response));
        return;
    }

    snprintf(json_body, json_size, "{\"storefront_id\":\"%s\",\"dev_token\":\"%s\",\"music_token\":\"%s\"}",
             g_storefront_id, g_dev_token, g_music_token);

    int json_len = strlen(json_body);

    // Format HTTP response with headers
    size_t response_size = 512;
    char *http_response = (char *)malloc(response_size);
    if (http_response == NULL)
    {
        fprintf(stderr, "[.] failed to allocate memory for HTTP response\n");
        free(json_body);
        const char *error_response = "HTTP/1.1 500 Internal Server Error\r\nContent-Type: application/json\r\nContent-Length: 0\r\n\r\n";
        writefull(connfd, (void *)error_response, strlen(error_response));
        return;
    }

    snprintf(http_response, response_size, "HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: %d\r\nConnection: close\r\n\r\n",
             json_len);

    DRM_DEBUG("[.] returning account info, storefront: %s\n", g_storefront_id);
    writefull(connfd, http_response, strlen(http_response));
    writefull(connfd, json_body, json_len);

    free(http_response);
    free(json_body);
}

void handle_progressive_mv(const int connfd)
{
    while (1) {
        uint8_t adamSize;
        if (!readfull(connfd, &adamSize, sizeof(uint8_t))) {
            return;
        }
        if (adamSize <= 0) {
            return;
        }
        char adam[adamSize + 1];
        for (int i = 0; i < adamSize; i++) {
            readfull(connfd, &adam[i], sizeof(uint8_t));
        }
        adam[adamSize] = '\0';
        char *ptr;
        unsigned long adamID = strtoul(adam, &ptr, 10);

        char *dk = NULL;
        /* Try HQ flavor first — returns progressive MP4 URL + downloadKey for
         * CDN server-side decryption. Fall back to HLS flavor if HQ fails. */
        const char *url = get_progressive_method_play(leaseMgr, adamID, &dk);
        if (url == NULL) {
            fprintf(stderr, "[.] mv HQ flavor failed for %lu, falling back to HLS\n", adamID);
            url = get_m3u8_method_play(leaseMgr, adamID, &dk);
        }
        if (url == NULL) {
            fprintf(stderr, "[.] mv progressive failed for adamId: %ld\n", adamID);
            writefull(connfd, "\n\n\n", 3);
        } else {
            /* Check if itun decryptor was created for this adamId */
            pthread_mutex_lock(&g_itun_mutex);
            int has_itun = (g_itun_decryptor.obj != NULL && g_itun_adam_id == adamID);
            pthread_mutex_unlock(&g_itun_mutex);

            const char *itun_flag = has_itun ? "ITUN" : "";
            DRM_DEBUG("[.] mv progressive adamId: %ld, url: %.80s..., key: %s, itun: %s\n",
                    adamID, url, dk ? dk : "(none)", has_itun ? "yes" : "no");

            /* protocol: URL\n KEY\n ITUN_FLAG\n */
            size_t url_len = strlen(url);
            size_t key_len = dk ? strlen(dk) : 0;
            size_t flag_len = strlen(itun_flag);
            size_t buf_len = url_len + 1 + key_len + 1 + flag_len + 1 + 1;
            char *buf = malloc(buf_len);
            if (buf) {
                snprintf(buf, buf_len, "%s\n%s\n%s\n", url, dk ? dk : "", itun_flag);
                writefull(connfd, buf, strlen(buf));
                free(buf);
            }
            free((void *)url);
            if (dk) free(dk);
        }
    }
}

static inline void *new_socket_mv(void *args)
{
    const int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (fd == -1) {
        perror("socket");
        return NULL;
    }
    const int optval = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    static struct sockaddr_in serv_addr = {.sin_family = AF_INET};
    inet_pton(AF_INET, args_info.host_arg, &serv_addr.sin_addr);
    serv_addr.sin_port = htons(args_info.mv_port_arg);

    if (bind(fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) {
        perror("bind mv");
        return NULL;
    }
    listen(fd, 1);
    fprintf(stderr, "[!] listening mv progressive request on %s:%d\n",
            args_info.host_arg, args_info.mv_port_arg);

    while (1) {
        const int connfd = accept(fd, NULL, NULL);
        if (connfd == -1) continue;
        handle_progressive_mv(connfd);
        close(connfd);
    }
}

/* itun sample decryption handler (port 50020).
 * Protocol:
 *   1. Client sends adamId_len (1 byte) + adamId string
 *   2. Loop: client sends sample_size (4 bytes LE) + sample_data
 *            server decrypts in-place, sends decrypted_size (4 bytes LE) + decrypted_data
 *   3. sample_size == 0 signals end of stream */
void handle_itun_decrypt(const int connfd) {
    while (1) {
        uint8_t adamSize;
        if (!readfull(connfd, &adamSize, sizeof(uint8_t)))
            return;
        if (adamSize <= 0)
            return;

        char adam[adamSize + 1];
        if (!readfull(connfd, adam, adamSize))
            return;
        adam[adamSize] = '\0';

        char *ptr;
        unsigned long adamID = strtoul(adam, &ptr, 10);

        pthread_mutex_lock(&g_itun_mutex);
        void *dec_obj = g_itun_decryptor.obj;
        unsigned long dec_adam = g_itun_adam_id;
        pthread_mutex_unlock(&g_itun_mutex);

        if (dec_obj == NULL) {
            fprintf(stderr, "[!] itun: no decryptor available (request MV URL first)\n");
            return;
        }
        if (dec_adam != adamID) {
            fprintf(stderr, "[!] itun: decryptor adamId mismatch: have %lu, got %lu\n", dec_adam, adamID);
            return;
        }

        DRM_DEBUG("[+] itun: decrypting samples for adamId %lu\n", adamID);

        while (1) {
            uint32_t size;
            if (!readfull(connfd, &size, sizeof(uint32_t))) {
                perror("itun read size");
                return;
            }

            if (size == 0)
                break;

            uint8_t *sample = malloc(size);
            if (sample == NULL) {
                perror("itun malloc");
                return;
            }
            if (!readfull(connfd, sample, size)) {
                free(sample);
                perror("itun read data");
                return;
            }

            uint32_t out_len = 0;
            _ZN17SVPastisDecryptor13decryptSampleEPKhRKjPj(
                dec_obj, sample, &size, &out_len);

            writefull(connfd, &out_len, sizeof(uint32_t));
            if (out_len > 0) {
                writefull(connfd, sample, out_len);
            }
            free(sample);
        }
    }
}

static inline void *new_socket_itun(void *args) {
    const int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (fd == -1) {
        perror("socket itun");
        return NULL;
    }
    const int optval = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    static struct sockaddr_in serv_addr = {.sin_family = AF_INET};
    inet_pton(AF_INET, args_info.host_arg, &serv_addr.sin_addr);
    serv_addr.sin_port = htons(args_info.mv_port_arg + 10000);  // 60020

    if (bind(fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) {
        perror("bind itun");
        return NULL;
    }
    listen(fd, 1);
    fprintf(stderr, "[!] listening itun decrypt on %s:%d\n",
            args_info.host_arg, args_info.mv_port_arg + 10000);

    while (1) {
        const int connfd = accept(fd, NULL, NULL);
        if (connfd == -1) continue;
        handle_itun_decrypt(connfd);
        close(connfd);
    }
}

static inline void *new_socket_account(void *args)
{
    const int fd = socket(AF_INET, SOCK_STREAM | SOCK_CLOEXEC, IPPROTO_TCP);
    if (fd == -1)
    {
        perror("socket");
        return NULL;
    }
    const int optval = 1;
    setsockopt(fd, SOL_SOCKET, SO_REUSEPORT, &optval, sizeof(optval));

    static struct sockaddr_in serv_addr = {.sin_family = AF_INET};
    inet_pton(AF_INET, args_info.host_arg, &serv_addr.sin_addr);
    serv_addr.sin_port = htons(args_info.account_port_arg);
    if (bind(fd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1)
    {
        perror("bind");
        return NULL;
    }

    if (listen(fd, 5) == -1)
    {
        perror("listen");
        return NULL;
    }

    fprintf(stderr, "[!] listening account info request on %s:%d\n", args_info.host_arg, args_info.account_port_arg);

    static struct sockaddr_in peer_addr;
    static socklen_t peer_addr_size = sizeof(peer_addr);
    while (1)
    {
        const int connfd = accept4(fd, (struct sockaddr *)&peer_addr,
                                   &peer_addr_size, SOCK_CLOEXEC);
        if (connfd == -1)
        {
            if (errno == ENETDOWN || errno == EPROTO || errno == ENOPROTOOPT ||
                errno == EHOSTDOWN || errno == ENONET ||
                errno == EHOSTUNREACH || errno == EOPNOTSUPP ||
                errno == ENETUNREACH)
                continue;
            perror("accept4");
        }

        handle_account(connfd);

        if (close(connfd) == -1)
        {
            perror("close");
        }
    }
}

char* get_account_storefront_id(struct shared_ptr reqCtx) {
    union std_string *region = malloc(sizeof(union std_string));
    struct shared_ptr urlbag = {.obj = 0x0, .ctrl_blk = 0x0};
    _ZNK17storeservicescore14RequestContext20storeFrontIdentifierERKNSt6__ndk110shared_ptrINS_6URLBagEEE(region, reqCtx.obj, &urlbag);
    const char *region_str = std_string_data(region);
    if (region_str) {
        char *result = strdup(region_str); 
        free(region);
        return result;
    } 
    return NULL;
}

void write_storefront_id(void) {
    FILE *fp = fopen(strcat_b(args_info.base_dir_arg, "/STOREFRONT_ID"), "w");
    DRM_DEBUG("[+] StoreFront ID: %s\n", g_storefront_id);
    fprintf(fp, "%s", g_storefront_id);
    fclose(fp);
}

char *get_guid() {
    char *ret[2];
    _ZN17storeservicescore10DeviceGUID4guidEv(ret, g_GUID.obj);
    char *raw = _ZNK13mediaplatform4Data5bytesEv(ret[0]);
    size_t len = _ZNK13mediaplatform4Data6lengthEv(ret[0]);
    /* Data::bytes() is NOT null-terminated — copy to a null-terminated buffer */
    char *guid = malloc(len + 1);
    if (!guid) return NULL;
    memcpy(guid, raw, len);
    guid[len] = '\0';
    return guid;
}

long long getCurrentTimeMillis() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec * 1000LL + tv.tv_usec / 1000;
}


char *get_music_user_token(char *guid, char *authToken, struct shared_ptr reqCtx){
    uint8_t *ptr = (uint8_t *)calloc(1, 2048);
    if (!ptr) return NULL;
    *(void **)(ptr) =
        &_ZTVNSt6__ndk120__shared_ptr_emplaceIN13mediaplatform11HTTPMessageENS_9allocatorIS2_EEEE +
        2;
    struct shared_ptr httpMessage = {.obj = ptr + 32, .ctrl_blk = ptr};
    union std_string url = new_std_string("https://play.itunes.apple.com/WebObjects/MZPlay.woa/wa/createMusicToken");
    union std_string method = new_std_string("POST");
    _ZN13mediaplatform11HTTPMessageC2ENSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_(httpMessage.obj, &url, &method);
    union std_string contentTypeHeader = new_std_string("Content-Type");
    union std_string contentTypeValue = new_std_string("application/json; charset=UTF-8");
    _ZN13mediaplatform11HTTPMessage9setHeaderERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_(httpMessage.obj, &contentTypeHeader, &contentTypeValue);
    union std_string expectHeader = new_std_string("Expect");
    union std_string expectValue = new_std_string("");
    _ZN13mediaplatform11HTTPMessage9setHeaderERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_(httpMessage.obj, &expectHeader, &expectValue);
    union std_string bundleIdHeader = new_std_string("X-Apple-Requesting-Bundle-Id");
    union std_string bundleIdValue = new_std_string("com.apple.android.music");
    _ZN13mediaplatform11HTTPMessage9setHeaderERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_(httpMessage.obj, &bundleIdHeader, &bundleIdValue);
    union std_string bundleVersionHeader = new_std_string("X-Apple-Requesting-Bundle-Version");
    union std_string bundleVersionValue = new_std_string("Music/4.9 Android/10 model/Samsung S9 build/7663313 (dt:66)");
    _ZN13mediaplatform11HTTPMessage9setHeaderERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_(httpMessage.obj, &bundleVersionHeader, &bundleVersionValue);
    /* The assertion is a JWT that can exceed any fixed buffer; serialise it with cJSON (PR #1). */
    char *body = drm_music_token_request(guid, authToken, getCurrentTimeMillis());
    if (body == NULL) {
        return NULL;
    }

    _ZN13mediaplatform11HTTPMessage11setBodyDataEPcm(httpMessage.obj, body, strlen(body));
    /* NOTE: do NOT free body before run() — new hybris stores pointer, not copy */
    uint8_t *urlRequest = (uint8_t *)calloc(1, 2048);
    if (!urlRequest) { free(ptr); return NULL; }
    _ZN17storeservicescore10URLRequestC2ERKNSt6__ndk110shared_ptrIN13mediaplatform11HTTPMessageEEERKNS2_INS_14RequestContextEEE(urlRequest, &httpMessage, &reqCtx);
    _ZN17storeservicescore10URLRequest3runEv(urlRequest);
    struct shared_ptr *err = _ZNK17storeservicescore10URLRequest5errorEv(urlRequest);
    if (err->obj != NULL) {
        int code = store_error_code(err->obj);
        const char *what = _ZNK17storeservicescore19StoreErrorCondition4whatEv(err->obj);
        fprintf(stderr, "[!] createMusicToken error: code=%d, message=%s\n", code, what ? what : "none");
        return NULL;
    }
    struct shared_ptr *urlResp = _ZNK17storeservicescore10URLRequest8responseEv(urlRequest);
    struct shared_ptr *resp = _ZNK17storeservicescore11URLResponse18underlyingResponseEv(urlResp->obj);
    void *http_message_obj = resp->obj;
    void* data_ptr = *(void**)((char*)http_message_obj + 48);
    char *respBody = data_ptr ? _ZNK13mediaplatform4Data5bytesEv(data_ptr) : NULL;
    cJSON *json = cJSON_Parse(respBody);
    cJSON *token_obj = cJSON_GetObjectItemCaseSensitive(json, "music_token");
    char *token = cJSON_GetStringValue(token_obj);
    if (token == NULL) {
        const char *err_desc = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(json, "error_description"));
        const char *err_code = cJSON_GetStringValue(cJSON_GetObjectItemCaseSensitive(json, "error"));
        fprintf(stderr, "[!] createMusicToken failed: %s (%s)\n",
                err_desc ? err_desc : "unknown error",
                err_code ? err_code : "?");
        return NULL;
    }
    char *result = strdup(token);
    return result;
}


char* get_dev_token(struct shared_ptr reqCtx) {
    uint8_t *ptr = (uint8_t *)calloc(1, 2048);
    if (!ptr) return NULL;
    *(void **)(ptr) =
        &_ZTVNSt6__ndk120__shared_ptr_emplaceIN13mediaplatform11HTTPMessageENS_9allocatorIS2_EEEE +
        2;
    struct shared_ptr httpMessage = {.obj = ptr + 32, .ctrl_blk = ptr};
    union std_string url = new_std_string("https://sf-api-token-service.itunes.apple.com/apiToken");
    union std_string method = new_std_string("GET");
    _ZN13mediaplatform11HTTPMessageC2ENSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES7_(httpMessage.obj, &url, &method);
    uint8_t *urlRequest = (uint8_t *)calloc(1, 2048);
    if (!urlRequest) { free(ptr); return NULL; }
    _ZN17storeservicescore10URLRequestC2ERKNSt6__ndk110shared_ptrIN13mediaplatform11HTTPMessageEEERKNS2_INS_14RequestContextEEE(urlRequest, &httpMessage, &reqCtx);
    union std_string clientIdName = new_std_string("clientId");
    union std_string clientIdValue = new_std_string("musicAndroid");
    _ZN17storeservicescore10URLRequest19setRequestParameterERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_(urlRequest, &clientIdName, &clientIdValue);
    union std_string versionName = new_std_string("version");
    union std_string versionValue = new_std_string("1");
    _ZN17storeservicescore10URLRequest19setRequestParameterERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEES9_(urlRequest, &versionName, &versionValue);
    _ZN17storeservicescore10URLRequest3runEv(urlRequest);
    struct shared_ptr *err = _ZNK17storeservicescore10URLRequest5errorEv(urlRequest);
    if (err->obj != NULL) {
        int code = store_error_code(err->obj);
        const char *what = _ZNK17storeservicescore19StoreErrorCondition4whatEv(err->obj);
        fprintf(stderr, "[!] devToken error: code=%d, message=%s\n", code, what ? what : "none");
        return NULL;
    }
    struct shared_ptr *urlResp = _ZNK17storeservicescore10URLRequest8responseEv(urlRequest);
    struct shared_ptr *resp = _ZNK17storeservicescore11URLResponse18underlyingResponseEv(urlResp->obj);
    void *http_message_obj = resp->obj;
    void** data_ptr_location = (void**)((char*)http_message_obj + 48);
    void* data_ptr = *data_ptr_location;
    char *respBody = _ZNK13mediaplatform4Data5bytesEv(data_ptr);
    cJSON *json = cJSON_Parse(respBody);
    cJSON *token_obj = cJSON_GetObjectItemCaseSensitive(json, "token");
    char *token = cJSON_GetStringValue(token_obj);
    if (token == NULL) {
        fprintf(stderr, "[!] devToken error: token field missing in response\n");
        return NULL;
    }
    char *result = strdup(token);
    return result;
}

void write_music_token(void) {
    if (!g_music_token || !g_music_token[0]) return;
    FILE *fp = fopen(strcat_b(args_info.base_dir_arg, "/MUSIC_TOKEN"), "w");
    if (!fp) { perror("[!] write_music_token: fopen"); return; }
    DRM_DEBUG("[+] Music-Token: %.14s...\n", g_music_token);
    fprintf(fp, "%s", g_music_token);
    fclose(fp);
}

int offline_available() {
    struct shared_ptr *fairplay = malloc(16);
    if (!fairplay) return 0;
    memset(fairplay, 0, 16);
    _ZN17storeservicescore14RequestContext8fairPlayEv(fairplay, reqCtx.obj);
    if (!fairplay->obj) {
        /* Account may lack a FairPlay subscription object — treat as offline-unavailable. */
        fprintf(stderr, "[drm] offline_available: FairPlay obj is null\n"); fflush(stderr);
        free(fairplay);
        return 0;
    }
    struct std_vector fairplay_status = _ZN17storeservicescore8FairPlay21getSubscriptionStatusEv(fairplay->obj);
    /* Empty or partial status is common before sign-in; never read past the vector (PR #1). */
    const int available = drm_subscription_offline_available(fairplay_status.begin, fairplay_status.end);
    free(fairplay);
    if (available) { // kFPSubscriptionCanPlayContent, kFPSubscriptionCanStreamAndPlayContent
        return 1;
    }
    return 0;
}

#ifndef DRM_LIB_BUILD
int main(int argc, char *argv[]) {
    cmdline_parser(argc, argv, &args_info);
    char *copy_that_needs_to_be_freed = NULL;
    split_string_safe(args_info.device_info_arg, "/", device_infos, 9, &copy_that_needs_to_be_freed);

    #ifndef MyRelease
    install_hooks();
    #endif

    drm_init_internal();
    hybris_init_callbacks();
    fprintf(stderr, "[main-cp1] calling init_ctx\n"); fflush(stderr);
    reqCtx = drm_init_ctx();
    fprintf(stderr, "[main-cp2] init_ctx returned reqCtx.obj=%p ctrl=%p\n", reqCtx.obj, reqCtx.ctrl_blk); fflush(stderr);
    write_drm_state("STARTING");
    fprintf(stderr, "[main-cp3] write_drm_state done\n"); fflush(stderr);
    if (args_info.login_given) {
        amUsername = strtok(args_info.login_arg, ":");
        amPassword = strtok(NULL, ":");
    }
    if (args_info.login_given && !mygo_native_account_login(reqCtx)) {
        fprintf(stderr, "[!] login failed\n");
        write_drm_state("FAILED");
        return EXIT_FAILURE;
    }
    fprintf(stderr, "[main-cp4] SVPlaybackLeaseManagerC2\n"); fflush(stderr);
    _ZN22SVPlaybackLeaseManagerC2ERKNSt6__ndk18functionIFvRKiEEERKNS1_IFvRKNS0_10shared_ptrIN17storeservicescore19StoreErrorConditionEEEEEE(
        leaseMgr, &endLeaseCallback, &pbErrCallback);
    fprintf(stderr, "[main-cp5] refreshLeaseAutomatically\n"); fflush(stderr);
    uint8_t autom = 1;
    _ZN22SVPlaybackLeaseManager25refreshLeaseAutomaticallyERKb(leaseMgr, &autom);
    fprintf(stderr, "[main-cp6] requestLease\n"); fflush(stderr);
    _ZN22SVPlaybackLeaseManager12requestLeaseERKb(leaseMgr, &autom);
    fprintf(stderr, "[main-cp7] SVFootHillSessionCtrl::instance\n"); fflush(stderr);
    FHinstance = _ZN21SVFootHillSessionCtrl8instanceEv();
    fprintf(stderr, "[main-cp8] start_recovery_thread\n"); fflush(stderr);

    /* Start the async recovery thread.  Must be started after leaseMgr and
     * FHinstance are initialised so that refresh_decrypt_ctx() is safe to call
     * from the worker at any point after this. */
    start_recovery_thread();
    fprintf(stderr, "[main-cp9] write_drm_state INITIALIZING_FAIRPLAY\n"); fflush(stderr);
    write_drm_state("INITIALIZING_FAIRPLAY");
    fprintf(stderr, "[main-cp10] offline_available\n"); fflush(stderr);
    offlineFlag = offline_available();
    fprintf(stderr, "[main-cp11] offline_available returned %d\n", offlineFlag); fflush(stderr);
    if (offlineFlag) {
        DRM_DEBUG("[+] This account supports offline channel\n");
    }

    // Cache account info
    g_storefront_id = get_account_storefront_id(reqCtx);
    if (g_storefront_id == NULL) {
        fprintf(stderr, "[!] failed to get storefront ID\n");
        write_drm_state("FAILED");
        return EXIT_FAILURE;
    }
    g_dev_token = get_dev_token(reqCtx);
    if (g_dev_token == NULL) {
        fprintf(stderr, "[!] failed to get dev token\n");
        write_drm_state("FAILED");
        return EXIT_FAILURE;
    }
    g_music_token = get_music_user_token(get_guid(), g_dev_token, reqCtx);
    if (g_music_token == NULL) {
        // [qemu-wl] refresh failed (e.g. expired session); fall back to cached MUSIC_TOKEN
        fprintf(stderr, "[!] failed to get music token (refresh); trying cached MUSIC_TOKEN\n");
        FILE *tf = fopen(strcat_b(args_info.base_dir_arg, "/MUSIC_TOKEN"), "r");
        if (tf != NULL) {
            char tbuf[256];
            size_t n = fread(tbuf, 1, sizeof(tbuf) - 1, tf);
            fclose(tf);
            tbuf[n] = '\0';
            char *s = tbuf;
            while (*s == ' ' || *s == '\n' || *s == '\r') s++;
            if (*s != '\0') {
                g_music_token = strdup(s);
                fprintf(stderr, "[!] using cached MUSIC_TOKEN (%.14s...)\n", g_music_token);
            }
        }
        if (g_music_token == NULL) {
            fprintf(stderr, "[!] failed to get music token\n");
            write_drm_state("FAILED");
            return EXIT_FAILURE;
        }
    }

    DRM_DEBUG("[+] account info cached successfully\n");

    write_storefront_id();
    write_music_token();
    write_drm_state("RUNNING");

    pthread_t m3u8_thread;
    pthread_create(&m3u8_thread, NULL, &new_socket_m3u8, NULL);
    pthread_detach(m3u8_thread);

    pthread_t account_thread;
    pthread_create(&account_thread, NULL, &new_socket_account, NULL);
    pthread_detach(account_thread);

    pthread_t key_thread;
    pthread_create(&key_thread, NULL, &new_socket_key, NULL);
    pthread_detach(key_thread);

    pthread_t mv_thread;
    pthread_create(&mv_thread, NULL, &new_socket_mv, NULL);
    pthread_detach(mv_thread);

    pthread_t itun_thread;
    pthread_create(&itun_thread, NULL, &new_socket_itun, NULL);
    pthread_detach(itun_thread);


    return new_socket();
}
#endif /* DRM_LIB_BUILD */
